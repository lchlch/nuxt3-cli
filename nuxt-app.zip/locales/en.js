export default {
  hello: "hello",
  greeting: 'greeting',
  button: 'button'
}