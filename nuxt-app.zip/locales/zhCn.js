export default {
  hello: "你好",
  greeting: '恭喜',
  button: '按钮'
}