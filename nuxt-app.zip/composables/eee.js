export const useCounter = () => useState('counter', () => 0)
export const useColor = () => useState('color', () => 'pink')